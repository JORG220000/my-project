import type { StreakState } from "./types";

const WEEK_TARGET_DAYS = 5;
const GRACE_PER_WEEK = 1;

export interface DayVerdict { counted: boolean; usedGrace: boolean; broken: boolean; }

/**
 * Streak по неделям, не по абсолютной цепочке:
 * день засчитан, если закрыто >= minDone из daily-задач.
 * Один провальный день в неделю поглощается grace-периодом.
 * Две плохие недели подряд режут streak наполовину, не обнуляют.
 */
export function evaluateDay(
  state: StreakState,
  date: string,
  doneCount: number,
  totalDaily: number,
  badDaysInWeek: number,
): DayVerdict {
  if (totalDaily === 0) return { counted: true, usedGrace: false, broken: false };
  const minDone = Math.max(1, Math.ceil(totalDaily * 0.6));
  if (doneCount >= minDone) return { counted: true, usedGrace: false, broken: false };
  if (badDaysInWeek <= GRACE_PER_WEEK && !state.graceUsedThisWeek) {
    return { counted: false, usedGrace: true, broken: false };
  }
  return { counted: false, usedGrace: false, broken: true };
}

export function applyBrokenWeek(streak: number): number {
  return Math.floor(streak / 2);
}

export { WEEK_TARGET_DAYS };
