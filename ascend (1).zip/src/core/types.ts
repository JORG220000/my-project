export type BranchCode =
  | "WILL" | "MIND" | "BODY" | "SKILL"
  | "FINANCE" | "INFLUENCE" | "KNOWLEDGE";

export type Difficulty = 1 | 2 | 3 | 4 | 5;

/** once — на один конкретный день. habit — каждый день, сброс в 00:00. */
export type TaskKind = "once" | "habit";

export interface Task {
  id: string;
  title: string;
  branch: BranchCode;
  baseXp: number;
  difficulty: Difficulty;
  kind: TaskKind;
  /** дата для kind=once (YYYY-MM-DD); у habit — undefined */
  dueDate?: string;
  /** требовать фото-доказательство при выполнении */
  photoRequired: boolean;
  recoveryOf?: string;
  archived: boolean;
  createdAt: string;
}

export interface TaskCompletion {
  id: string;
  taskId: string;
  date: string;
  xpAwarded: number;
  meritsAwarded: number;
  recovered: boolean;
  /** dataURL сжатого фото-доказательства */
  photo?: string;
  createdAt: string;
}

export type FailReason =
  | "no_time" | "no_energy" | "wrong_estimate" | "procrastination" | "force_majeure";

export interface TaskFailure {
  id: string;
  taskId: string;
  date: string;
  reason: FailReason;
  recoveryTaskId?: string;
}

export type XpSource = "task" | "milestone" | "achievement" | "recovery" | "review";

export interface XpTransaction {
  id: string;
  branch: BranchCode;
  amount: number;
  source: XpSource;
  refId?: string;
  voidOf?: string;
  createdAt: string;
}

export interface MeritTransaction {
  id: string;
  amount: number;
  reason: string;
  createdAt: string;
}

export interface BranchState {
  branch: BranchCode;
  level: number;
  xp: number;
  totalXp: number;
}

export interface CharacterState {
  level: number;
  totalXp: number;
  branches: Record<BranchCode, BranchState>;
}

export interface Reward {
  id: string;
  title: string;
  meritCost: number;
  redeemedAt?: string;
}

export interface StreakState {
  current: number;
  best: number;
  graceUsedThisWeek: boolean;
  lastCountedDate: string;
}
