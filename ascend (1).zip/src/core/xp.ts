import type { Difficulty } from "./types";

const DIFF_MULT: Record<Difficulty, number> = {
  1: 1.0, 2: 1.2, 3: 1.5, 4: 1.8, 5: 2.2,
};

const STREAK_STEP = 0.02;
const STREAK_CAP = 1.2;
const FOCUS_MULT = 1.1;
const REPEAT_SAME_DAY_MULT = 0.3;
const MERIT_RATE = 0.25;

/** XP одного выполнения задачи. */
export function taskXp(params: {
  baseXp: number;
  difficulty: Difficulty;
  streakDays: number; // текущая серия дней
  viaFocusTimer: boolean;
  sameTaskDoneTodayCount: number; // сколько раз эта задача уже закрыта сегодня
}): number {
  const streakMult = Math.min(1 + STREAK_STEP * params.streakDays, STREAK_CAP);
  const focusMult = params.viaFocusTimer ? FOCUS_MULT : 1;
  const repeatMult =
    params.sameTaskDoneTodayCount === 0 ? 1 : REPEAT_SAME_DAY_MULT;
  const raw =
    params.baseXp * DIFF_MULT[params.difficulty] * streakMult * focusMult * repeatMult;
  return Math.round(raw);
}

/** Merits начисляются параллельно XP, отдельной валютой. */
export function meritsFor(xp: number): number {
  return Math.max(1, Math.ceil(xp * MERIT_RATE));
}

/** Повторяющаяся задача не должна фармиться бесконечно за день. */
export function canCompleteAgainToday(sameTaskDoneTodayCount: number): boolean {
  return sameTaskDoneTodayCount < 2;
}
