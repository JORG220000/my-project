import type { BranchCode } from "./types";

export interface BranchMeta {
  code: BranchCode;
  name: string;
  icon: string;
  substats: string[];
}

/** Сид-данные веток. Подхарактеристики — readonly-аналитика. */
export const BRANCHES: BranchMeta[] = [
  { code: "WILL", name: "Воля", icon: "⚔️", substats: ["Discipline", "Persistence", "Consistency", "Courage", "Self-control"] },
  { code: "MIND", name: "Разум", icon: "♟️", substats: ["Logic", "Mathematics", "Critical Thinking", "Strategy", "Problem Solving"] },
  { code: "BODY", name: "Тело", icon: "💪", substats: ["Strength", "Endurance", "Mobility", "Sport Discipline"] },
  { code: "SKILL", name: "Навыки", icon: "💻", substats: ["Programming", "Web", "Design", "Content", "AI"] },
  { code: "FINANCE", name: "Финансы", icon: "💰", substats: ["Earning", "Literacy", "Projects", "Saving"] },
  { code: "INFLUENCE", name: "Влияние", icon: "👑", substats: ["Communication", "Leadership", "Reputation", "Networking", "Negotiation", "PM", "Public Speaking"] },
  { code: "KNOWLEDGE", name: "Знания", icon: "🌍", substats: ["Psychology", "History", "Economics", "Politics", "Strategy", "Philosophy", "Science"] },
];

export const BRANCH_CODES = BRANCHES.map((b) => b.code) as BranchCode[];
