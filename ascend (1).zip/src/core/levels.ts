/**
 * requiredXp(n) — XP для перехода n -> n+1.
 * Экспонента с затуханием: быстрый старт, честный год.
 */
export function requiredXp(level: number): number {
  return Math.round(80 * Math.pow(level, 1.6));
}

/** Кумулятивный XP, нужный для достижения уровня (уровень 1 = 0). */
export function totalXpForLevel(level: number): number {
  let total = 0;
  for (let n = 1; n < level; n++) total += requiredXp(n);
  return total;
}

export function levelForTotalXp(totalXp: number): number {
  let level = 1;
  let remaining = totalXp;
  while (remaining >= requiredXp(level)) {
    remaining -= requiredXp(level);
    level++;
  }
  return level;
}

/** Прогресс внутри текущего уровня: 0..1 */
export function levelProgress(totalXp: number): number {
  const level = levelForTotalXp(totalXp);
  const floor = totalXpForLevel(level);
  return (totalXp - floor) / requiredXp(level);
}
