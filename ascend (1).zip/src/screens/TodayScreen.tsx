import { useMemo, useRef, useState } from "react";
import { useGameStore, type NewTaskInput } from "../state/useGameStore";
import { service } from "../services";
import { todayStr, levelProgress, requiredXp } from "../services/gameService";
import { BRANCHES } from "../core/branches";
import { compressPhoto } from "../utils/photo";
import type { BranchCode, Difficulty, Task, TaskKind } from "../core/types";

export default function TodayScreen() {
  const { character, branchMeta, completeTask, activeTasks, completedTodayIds } = useGameStore();
  const [showAdd, setShowAdd] = useState(false);
  const [proofTask, setProofTask] = useState<Task | null>(null);

  const date = todayStr();
  const tasks = activeTasks();
  const doneIds = completedTodayIds();
  const stats = useMemo(() => service.todayStats(date), [doneIds]); // eslint-disable-line
  const progress = levelProgress(character.totalXp);

  const onCheck = (t: Task) => {
    if (doneIds.has(t.id)) return;
    if (t.photoRequired) setProofTask(t); // сначала фото
    else completeTask(t.id);
  };

  return (
    <div className="screen">
      <div className="level-hero">
        <div className="cap">Level {character.level}</div>
        <div className="lvl">{character.totalXp.toLocaleString("ru-RU")} XP</div>
        <div className="xpbar"><div style={{ width: `${Math.round(progress * 100)}%` }} /></div>
        <div className="xpbar-label">
          до уровня {character.level + 1}: <b>{requiredXp(character.level)} XP</b>
          {" · сегодня: "}<b>{stats.xpToday} XP</b>
        </div>
      </div>

      <h1 className="section">Квесты · {date}</h1>
      {tasks.length === 0 && <div className="empty">План пуст. Добавь первый квест.</div>}
      {tasks.map((t) => {
        const done = doneIds.has(t.id);
        const branch = branchMeta.find((b) => b.code === t.branch)!;
        return (
          <div key={t.id} className={`quest ${done ? "done" : ""}`} onClick={() => onCheck(t)}>
            <div className="check" />
            <div className="info">
              <div className="title">{t.title}</div>
              <div className="meta">
                {branch.name} · сложность {t.difficulty}/5
                {t.kind === "habit" ? " · привычка" : ` · разово · ${t.dueDate}`}
              </div>
            </div>
            {t.photoRequired && <span className="cam">◉</span>}
            <div className="xp">+{t.baseXp}</div>
          </div>
        );
      })}

      <h1 className="section">Ветки</h1>
      {branchMeta.map((b) => {
        const st = character.branches[b.code];
        const pct = Math.round((st.xp / requiredXp(st.level)) * 100);
        return (
          <div key={b.code} className="branch-row">
            <div className="head">
              <span className="name">{b.icon} {b.name}</span>
              <span className="val">Lv {st.level} · {st.xp}/{requiredXp(st.level)}</span>
            </div>
            <div className="xpbar"><div style={{ width: `${pct}%` }} /></div>
          </div>
        );
      })}

      <button className="fab" onClick={() => setShowAdd(true)} aria-label="Добавить квест">+</button>
      {showAdd && <AddTaskSheet onClose={() => setShowAdd(false)} />}
      {proofTask && (
        <ProofSheet
          task={proofTask}
          onClose={() => setProofTask(null)}
          onConfirm={(photo) => { completeTask(proofTask.id, photo); setProofTask(null); }}
        />
      )}
    </div>
  );
}

/* ---------- добавление квеста ---------- */
function AddTaskSheet({ onClose }: { onClose: () => void }) {
  const { addTask } = useGameStore();
  const [title, setTitle] = useState("");
  const [branch, setBranch] = useState<BranchCode>("WILL");
  const [baseXp, setBaseXp] = useState(30);
  const [difficulty, setDifficulty] = useState<Difficulty>(2);
  const [kind, setKind] = useState<TaskKind>("habit");
  const [dueDate, setDueDate] = useState(todayStr());
  const [photoRequired, setPhotoRequired] = useState(false);

  const canSave = title.trim().length > 0 && baseXp > 0 && (kind === "habit" || !!dueDate);

  const save = () => {
    if (!canSave) return;
    const input: NewTaskInput = {
      title: title.trim(), branch, baseXp, difficulty, kind,
      dueDate: kind === "once" ? dueDate : undefined, photoRequired,
    };
    addTask(input);
    onClose();
  };

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="grab" />
        <h2>Новый квест</h2>

        <div className="field">
          <label>Название</label>
          <input type="text" value={title} placeholder="Что нужно сделать"
            onChange={(e) => setTitle(e.target.value)} autoFocus />
        </div>

        <div className="field">
          <label>Ветка</label>
          <div className="pills">
            {BRANCHES.map((b) => (
              <button key={b.code} className={`pill ${branch === b.code ? "active" : ""}`}
                onClick={() => setBranch(b.code)}>
                {b.icon} {b.name}
              </button>
            ))}
          </div>
        </div>

        <div className="field">
          <label>Тип</label>
          <div className="seg">
            <button className={kind === "once" ? "active" : ""} onClick={() => setKind("once")}>Один день</button>
            <button className={kind === "habit" ? "active" : ""} onClick={() => setKind("habit")}>Привычка</button>
          </div>
        </div>

        {kind === "once" && (
          <div className="field">
            <label>Дата выполнения</label>
            <input type="date" value={dueDate} min={todayStr()}
              onChange={(e) => setDueDate(e.target.value)} />
          </div>
        )}

        <div className="field">
          <label>Сложность · {difficulty}/5</label>
          <div className="seg">
            {[1, 2, 3, 4, 5].map((d) => (
              <button key={d} className={difficulty === d ? "active" : ""}
                onClick={() => setDifficulty(d as Difficulty)}>{d}</button>
            ))}
          </div>
        </div>

        <div className="field">
          <label>Базовый XP</label>
          <input type="number" value={baseXp} min={5} max={500} step={5}
            onChange={(e) => setBaseXp(Math.max(5, Number(e.target.value) || 5))} />
        </div>

        <div className="switch-row" onClick={() => setPhotoRequired(!photoRequired)}>
          <div>
            Фото-доказательство
            <div className="hint">После отметки попросит снимок с места выполнения</div>
          </div>
          <button className={`switch ${photoRequired ? "on" : ""}`} aria-label="фото" />
        </div>

        <button className="btn" disabled={!canSave} onClick={save}>Создать квест</button>
        <div style={{ height: 10 }} />
        <button className="btn ghost" onClick={onClose}>Отмена</button>
      </div>
    </div>
  );
}

/* ---------- фото-доказательство ---------- */
function ProofSheet({ task, onClose, onConfirm }: {
  task: Task; onClose: () => void; onConfirm: (photo: string) => void;
}) {
  const [photo, setPhoto] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    setBusy(true);
    try {
      setPhoto(await compressPhoto(f));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="grab" />
        <h2>Quest completed</h2>
        <div className="field">
          <label>{task.title} · +{task.baseXp} XP</label>
        </div>
        <input ref={fileRef} type="file" accept="image/*" capture="environment"
          style={{ display: "none" }} onChange={(e) => onFile(e.target.files?.[0])} />

        {photo ? (
          <>
            <img className="proof-preview" src={photo} alt="proof" />
            <button className="btn" onClick={() => onConfirm(photo)}>Подтвердить выполнение</button>
            <div style={{ height: 10 }} />
            <button className="btn ghost" onClick={() => fileRef.current?.click()}>Переснять</button>
          </>
        ) : (
          <>
            <div className="photo-drop" onClick={() => fileRef.current?.click()}>
              {busy ? "Обработка…" : <><b>Сделать фото</b><br />доказательство выполнения</>}
            </div>
            <button className="btn ghost" onClick={onClose}>Отмена</button>
          </>
        )}
      </div>
    </div>
  );
}
