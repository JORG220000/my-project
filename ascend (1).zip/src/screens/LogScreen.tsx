import { useMemo } from "react";
import { localStorageStorage } from "../data/localStorageStorage";

export default function LogScreen() {
  const days = useMemo(() => {
    const completions = localStorageStorage.loadCompletions();
    const byDate = new Map<string, number>();
    for (const c of completions) byDate.set(c.date, (byDate.get(c.date) ?? 0) + c.xpAwarded);
    return [...byDate.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, []);
  const xp = localStorageStorage.loadXp();
  const streak = localStorageStorage.loadStreak();

  return (
    <div className="screen">
      <h1 className="section">История</h1>
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
          <span>Streak</span>
          <span style={{ color: "var(--accent)" }}>{streak.current} дн. (лучший: {streak.best})</span>
        </div>
      </div>
      {days.length === 0 && <div className="empty">Пусто. Дни появятся по мере закрытия квестов.</div>}
      {days.map(([date, xpDay]) => (
        <div key={date} className="card">
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
            <span>{date}</span>
            <span style={{ color: "var(--accent)" }}>{xpDay} XP</span>
          </div>
        </div>
      ))}
      <h1 className="section">Транзакции XP</h1>
      {[...xp].reverse().slice(0, 50).map((t) => (
        <div key={t.id} className="card" style={{ fontSize: 13 }}>
          <span style={{ color: "var(--accent)" }}>+{t.amount}</span>{" "}
          {t.branch} · {t.source} · {t.createdAt.slice(0, 10)}
        </div>
      ))}
    </div>
  );
}
