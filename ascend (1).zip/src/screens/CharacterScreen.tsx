import { useGameStore } from "../state/useGameStore";
import { requiredXp } from "../services/gameService";

export default function CharacterScreen() {
  const { character, branchMeta } = useGameStore();
  return (
    <div className="screen">
      <div className="level-hero">
        <div className="cap">Character</div>
        <div className="lvl">LEVEL {character.level}</div>
        <div className="xpbar-label">всего {character.totalXp.toLocaleString("ru-RU")} XP</div>
      </div>

      {branchMeta.map((b) => {
        const st = character.branches[b.code];
        return (
          <div key={b.code} className="card">
            <div className="branch-row">
              <div className="head">
                <span className="name">{b.icon} {b.name}</span>
                <span className="val">Lv {st.level} · {st.totalXp} XP всего</span>
              </div>
              <div className="xpbar">
                <div style={{ width: `${Math.round((st.xp / requiredXp(st.level)) * 100)}%` }} />
              </div>
            </div>
            <div className="xpbar-label">{b.substats.join(" · ")}</div>
          </div>
        );
      })}
    </div>
  );
}
