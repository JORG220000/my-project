export default function PlaceholderScreen({ title, note }: { title: string; note: string }) {
  return (
    <div className="screen">
      <div className="level-hero">
        <div className="cap">{title}</div>
        <div className="lvl" style={{ fontSize: 18 }}>Фаза 2</div>
      </div>
      <div className="card" style={{ marginTop: 16 }}>
        <div className="xpbar-label" style={{ fontSize: 14, lineHeight: 1.6 }}>{note}</div>
      </div>
    </div>
  );
}
