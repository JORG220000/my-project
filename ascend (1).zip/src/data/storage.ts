import type {
  BranchCode, CharacterState, MeritTransaction, Reward, StreakState,
  Task, TaskCompletion, TaskFailure, XpTransaction,
} from "../core/types";

/**
 * Интерфейс репозитория. Текущая реализация — localStorage,
 * целевая — @capacitor-community/sqlite. Замена не трогает сервисы.
 */
export interface GameStorage {
  loadTasks(): Task[];
  saveTask(t: Task): void;
  loadCompletions(): TaskCompletion[];
  saveCompletion(c: TaskCompletion): void;
  loadFailures(): TaskFailure[];
  saveFailure(f: TaskFailure): void;
  loadXp(): XpTransaction[];
  saveXp(tx: XpTransaction): void;
  loadMerits(): MeritTransaction[];
  saveMerit(tx: MeritTransaction): void;
  loadCharacter(): CharacterState | null;
  saveCharacter(c: CharacterState): void;
  loadStreak(): StreakState;
  saveStreak(s: StreakState): void;
  loadRewards(): Reward[];
  saveReward(r: Reward): void;
  branchTotals(): Record<BranchCode, number>;
}
