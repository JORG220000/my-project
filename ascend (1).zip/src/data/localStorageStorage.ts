import type {
  BranchCode, CharacterState, MeritTransaction, Reward, StreakState,
  Task, TaskCompletion, TaskFailure, XpTransaction,
} from "../core/types";
import { BRANCH_CODES } from "../core/branches";
import type { GameStorage } from "./storage";

const K = {
  tasks: "ascend.tasks",
  completions: "ascend.completions",
  failures: "ascend.failures",
  xp: "ascend.xp",
  merits: "ascend.merits",
  character: "ascend.character",
  streak: "ascend.streak",
  rewards: "ascend.rewards",
} as const;

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown): void {
  localStorage.setItem(key, JSON.stringify(value));
}

export const localStorageStorage: GameStorage = {
  loadTasks: () => read<Task[]>(K.tasks, []),
  saveTask(t) {
    const all = read<Task[]>(K.tasks, []);
    const i = all.findIndex((x) => x.id === t.id);
    if (i >= 0) all[i] = t; else all.push(t);
    write(K.tasks, all);
  },
  loadCompletions: () => read<TaskCompletion[]>(K.completions, []),
  saveCompletion(c) {
    write(K.completions, [...read<TaskCompletion[]>(K.completions, []), c]);
  },
  loadFailures: () => read<TaskFailure[]>(K.failures, []),
  saveFailure(f) {
    write(K.failures, [...read<TaskFailure[]>(K.failures, []), f]);
  },
  loadXp: () => read<XpTransaction[]>(K.xp, []),
  saveXp(tx) {
    write(K.xp, [...read<XpTransaction[]>(K.xp, []), tx]);
  },
  loadMerits: () => read<MeritTransaction[]>(K.merits, []),
  saveMerit(tx) {
    write(K.merits, [...read<MeritTransaction[]>(K.merits, []), tx]);
  },
  loadCharacter: () => read<CharacterState | null>(K.character, null),
  saveCharacter: (c) => write(K.character, c),
  loadStreak: () =>
    read<StreakState>(K.streak, {
      current: 0, best: 0, graceUsedThisWeek: false, lastCountedDate: "",
    }),
  saveStreak: (s) => write(K.streak, s),
  loadRewards: () => read<Reward[]>(K.rewards, []),
  saveReward(r) {
    const all = read<Reward[]>(K.rewards, []);
    const i = all.findIndex((x) => x.id === r.id);
    if (i >= 0) all[i] = r; else all.push(r);
    write(K.rewards, all);
  },
  branchTotals() {
    const xp = read<XpTransaction[]>(K.xp, []);
    const totals = Object.fromEntries(BRANCH_CODES.map((c) => [c, 0])) as Record<BranchCode, number>;
    for (const tx of xp) if (!tx.voidOf) totals[tx.branch] += tx.amount;
    return totals;
  },
};
