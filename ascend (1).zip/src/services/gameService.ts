import { format } from "date-fns";
import { taskXp, meritsFor } from "../core/xp";
import { levelForTotalXp, totalXpForLevel } from "../core/levels";
import { BRANCH_CODES } from "../core/branches";
import type {
  CharacterState, Task, TaskCompletion, XpTransaction,
} from "../core/types";
import type { GameStorage } from "../data/storage";

export const uid = () => Math.random().toString(36).slice(2, 10);

export function todayStr(d: Date = new Date()): string {
  return format(d, "yyyy-MM-dd");
}

export class GameService {
  constructor(private store: GameStorage) {}

  /** Задачи, видимые на дату: привычки всегда, разовые — в свой dueDate. */
  activeTasksFor(date: string): Task[] {
    return this.store
      .loadTasks()
      .filter((t) => !t.archived && (t.kind === "habit" || t.dueDate === date));
  }

  isCompletedOn(taskId: string, date: string): boolean {
    return this.store
      .loadCompletions()
      .some((c) => c.taskId === taskId && c.date === date);
  }

  /** Завершение квеста. Один раз в день на задачу — повтор игнорируется (null). */
  completeTask(
    task: Task,
    opts: { viaFocusTimer?: boolean; date?: string; photo?: string } = {},
  ): TaskCompletion | null {
    const date = opts.date ?? todayStr();
    if (this.isCompletedOn(task.id, date)) return null;

    const doneToday = this.store
      .loadCompletions()
      .filter((c) => c.taskId === task.id && c.date === date).length;

    const xp = taskXp({
      baseXp: task.baseXp,
      difficulty: task.difficulty,
      streakDays: this.store.loadStreak().current,
      viaFocusTimer: opts.viaFocusTimer ?? false,
      sameTaskDoneTodayCount: doneToday,
    });
    const merits = meritsFor(xp);

    const completion: TaskCompletion = {
      id: uid(), taskId: task.id, date, xpAwarded: xp,
      meritsAwarded: merits, recovered: !!task.recoveryOf,
      photo: opts.photo, createdAt: new Date().toISOString(),
    };
    this.store.saveCompletion(completion);

    const tx: XpTransaction = {
      id: uid(), branch: task.branch, amount: xp,
      source: task.recoveryOf ? "recovery" : "task",
      refId: completion.id, createdAt: new Date().toISOString(),
    };
    this.store.saveXp(tx);
    this.store.saveMerit({
      id: uid(), amount: merits,
      reason: `quest: ${task.title}`, createdAt: new Date().toISOString(),
    });

    this.recomputeCharacter();
    return completion;
  }

  recomputeCharacter(): CharacterState {
    const totals = this.store.branchTotals();
    let grand = 0;
    const branches = {} as CharacterState["branches"];
    for (const code of BRANCH_CODES) {
      const totalXp = totals[code];
      grand += totalXp;
      const level = levelForTotalXp(totalXp);
      branches[code] = {
        branch: code, level, totalXp,
        xp: totalXp - totalXpForLevel(level),
      };
    }
    const state: CharacterState = {
      level: levelForTotalXp(grand), totalXp: grand, branches,
    };
    this.store.saveCharacter(state);
    return state;
  }

  meritBalance(): number {
    return this.store.loadMerits().reduce((s, t) => s + t.amount, 0);
  }

  todayStats(date: string = todayStr()) {
    const completions = this.store.loadCompletions().filter((c) => c.date === date);
    const xpToday = completions.reduce((s, c) => s + c.xpAwarded, 0);
    return { completions, xpToday, count: completions.length };
  }
}

export { levelForTotalXp, totalXpForLevel };
export { levelProgress, requiredXp } from "../core/levels";
