import { localStorageStorage } from "../data/localStorageStorage";
import { GameService } from "./gameService";

export const service = new GameService(localStorageStorage);
