import { NavLink, Route, Routes } from "react-router-dom";
import { useEffect } from "react";
import { useGameStore } from "./state/useGameStore";
import TodayScreen from "./screens/TodayScreen";
import CharacterScreen from "./screens/CharacterScreen";
import LogScreen from "./screens/LogScreen";
import PlaceholderScreen from "./screens/PlaceholderScreen";

export default function App() {
  const init = useGameStore((s) => s.init);
  useEffect(() => { init(); }, [init]);

  return (
    <div className="app">
      <Routes>
        <Route path="/" element={<TodayScreen />} />
        <Route path="/character" element={<CharacterScreen />} />
        <Route path="/log" element={<LogScreen />} />
        <Route path="/finance" element={<PlaceholderScreen title="Finance" note="MVP-фаза: записи доходов/расходов и цели. Данные хранятся отдельно от XP-ветки." />} />
        <Route path="/vault" element={<PlaceholderScreen title="Vault" note="Книги и база знаний — фаза 2." />} />
      </Routes>
      <nav className="tabbar">
        <NavLink to="/" end><span className="ico">◈</span>Today</NavLink>
        <NavLink to="/character"><span className="ico">▲</span>Progress</NavLink>
        <NavLink to="/log"><span className="ico">▦</span>Log</NavLink>
        <NavLink to="/finance"><span className="ico">₽</span>Finance</NavLink>
        <NavLink to="/vault"><span className="ico">▤</span>Vault</NavLink>
      </nav>
    </div>
  );
}
