import { create } from "zustand";
import { localStorageStorage } from "../data/localStorageStorage";
import { GameService, todayStr } from "../services/gameService";
import { BRANCHES } from "../core/branches";
import type { CharacterState, Task, TaskKind, BranchCode, Difficulty } from "../core/types";

const service = new GameService(localStorageStorage);

const SEED_TASKS: Array<{
  title: string; branch: BranchCode; baseXp: number; difficulty: Difficulty;
  kind: TaskKind; photoRequired: boolean;
}> = [
  { title: "Профильная математика", branch: "MIND", baseXp: 30, difficulty: 3, kind: "habit", photoRequired: false },
  { title: "Физика", branch: "MIND", baseXp: 30, difficulty: 3, kind: "habit", photoRequired: false },
  { title: "Работа над проектом", branch: "SKILL", baseXp: 50, difficulty: 4, kind: "habit", photoRequired: true },
  { title: "Книга (30 страниц)", branch: "KNOWLEDGE", baseXp: 20, difficulty: 2, kind: "habit", photoRequired: false },
  { title: "Дзюдо", branch: "BODY", baseXp: 40, difficulty: 3, kind: "habit", photoRequired: true },
];

export interface NewTaskInput {
  title: string;
  branch: BranchCode;
  baseXp: number;
  difficulty: Difficulty;
  kind: TaskKind;
  dueDate?: string; // обязателен для kind=once
  photoRequired: boolean;
}

interface GameStore {
  character: CharacterState;
  branchMeta: typeof BRANCHES;
  init(): void;
  completeTask(taskId: string, photo?: string): void;
  addTask(input: NewTaskInput): void;
  /** задачи, активные на сегодня (привычки + разовые на сегодня) */
  activeTasks(): Task[];
  completedTodayIds(): Set<string>;
}

export const useGameStore = create<GameStore>((set, get) => ({
  character: service.recomputeCharacter(),
  branchMeta: BRANCHES,

  init() {
    if (localStorageStorage.loadTasks().length === 0) {
      for (const t of SEED_TASKS) {
        localStorageStorage.saveTask({
          ...t, id: Math.random().toString(36).slice(2, 10),
          archived: false, createdAt: new Date().toISOString(),
        });
      }
    }
    set({ character: service.recomputeCharacter() });
  },

  completeTask(taskId, photo) {
    const task = get().activeTasks().find((t) => t.id === taskId);
    if (!task) return;
    const done = service.completeTask(task, { photo });
    if (done) set({ character: service.recomputeCharacter() });
  },

  addTask(input) {
    if (input.kind === "once" && !input.dueDate) input.dueDate = todayStr();
    localStorageStorage.saveTask({
      ...input, id: Math.random().toString(36).slice(2, 10),
      archived: false, createdAt: new Date().toISOString(),
    });
    set({ character: service.recomputeCharacter() });
  },

  activeTasks: () => service.activeTasksFor(todayStr()),
  completedTodayIds: () =>
    new Set(service.todayStats().completions.map((c) => c.taskId)),
}));
