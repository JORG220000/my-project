import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.ascend.personal",
  appName: "ASCEND",
  webDir: "dist",
  ios: {
    contentInset: "automatic",
  },
};

export default config;
