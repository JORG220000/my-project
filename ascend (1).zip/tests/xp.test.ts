import { describe, it, expect } from "vitest";
import { taskXp, meritsFor, canCompleteAgainToday } from "../src/core/xp";

describe("xp engine", () => {
  it("base задача даёт baseXp при сложности 1", () => {
    expect(taskXp({ baseXp: 30, difficulty: 1, streakDays: 0, viaFocusTimer: false, sameTaskDoneTodayCount: 0 })).toBe(30);
  });
  it("сложность и стрик умножают", () => {
    const base = taskXp({ baseXp: 30, difficulty: 1, streakDays: 0, viaFocusTimer: false, sameTaskDoneTodayCount: 0 });
    const hard = taskXp({ baseXp: 30, difficulty: 5, streakDays: 0, viaFocusTimer: false, sameTaskDoneTodayCount: 0 });
    expect(hard / base).toBeCloseTo(2.2, 5);
  });
  it("стрик-мультипликатор капается на 1.2", () => {
    const a = taskXp({ baseXp: 100, difficulty: 1, streakDays: 100, viaFocusTimer: false, sameTaskDoneTodayCount: 0 });
    const b = taskXp({ baseXp: 100, difficulty: 1, streakDays: 10, viaFocusTimer: false, sameTaskDoneTodayCount: 0 });
    expect(a).toBe(b);
  });
  it("повтор той же задачи в тот же день срезает до 0.3", () => {
    const first = taskXp({ baseXp: 30, difficulty: 1, streakDays: 0, viaFocusTimer: false, sameTaskDoneTodayCount: 0 });
    const again = taskXp({ baseXp: 30, difficulty: 1, streakDays: 0, viaFocusTimer: false, sameTaskDoneTodayCount: 1 });
    expect(again / first).toBeCloseTo(0.3, 5);
  });
  it("merits = 0.25 от XP, минимум 1", () => {
    expect(meritsFor(40)).toBe(10);
    expect(meritsFor(1)).toBe(1);
  });
  it("нельзя закрыть задачу больше 2 раз в день", () => {
    expect(canCompleteAgainToday(0)).toBe(true);
    expect(canCompleteAgainToday(1)).toBe(true);
    expect(canCompleteAgainToday(2)).toBe(false);
  });
});
