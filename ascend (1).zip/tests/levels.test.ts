import { describe, it, expect } from "vitest";
import { requiredXp, levelForTotalXp, totalXpForLevel, levelProgress } from "../src/core/levels";

describe("levels", () => {
  it("requiredXp растёт экспоненциально", () => {
    expect(requiredXp(1)).toBe(80);
    expect(requiredXp(2)).toBe(240);
    expect(requiredXp(10)).toBeGreaterThan(requiredXp(5) * 2);
  });
  it("levelForTotalXp инвертирует totalXpForLevel", () => {
    for (const lvl of [1, 2, 3, 5, 10, 20]) {
      expect(levelForTotalXp(totalXpForLevel(lvl))).toBe(lvl);
    }
  });
  it("progress внутри уровня 0..1", () => {
    const t = totalXpForLevel(5);
    expect(levelProgress(t)).toBe(0);
    expect(levelProgress(t + requiredXp(5))).toBe(0);
    const mid = levelProgress(t + requiredXp(5) / 2);
    expect(mid).toBeGreaterThan(0.4);
    expect(mid).toBeLessThan(0.6);
  });
});
