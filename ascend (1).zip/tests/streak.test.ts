import { describe, it, expect } from "vitest";
import { evaluateDay, applyBrokenWeek } from "../src/core/streak";
import type { StreakState } from "../src/core/types";

const base: StreakState = { current: 5, best: 8, graceUsedThisWeek: false, lastCountedDate: "" };

describe("streak", () => {
  it("день засчитан при >=60% выполнения", () => {
    expect(evaluateDay(base, "2026-09-21", 3, 5, 0).counted).toBe(true);
  });
  it("первый плохой день недели поглощается grace", () => {
    const v = evaluateDay(base, "2026-09-21", 0, 5, 1);
    expect(v.usedGrace).toBe(true);
    expect(v.broken).toBe(false);
  });
  it("второй плохой день подряд — broken", () => {
    expect(evaluateDay(base, "2026-09-21", 0, 5, 2).broken).toBe(true);
  });
  it("плохая неделя режет streak вдвое, не обнуляет", () => {
    expect(applyBrokenWeek(7)).toBe(3);
    expect(applyBrokenWeek(1)).toBe(0);
  });
});
