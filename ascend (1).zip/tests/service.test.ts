import { describe, it, expect, beforeEach } from "vitest";
import { GameService } from "../src/services/gameService";
import type { GameStorage } from "../src/data/storage";
import type {
  BranchCode, CharacterState, MeritTransaction, Reward, StreakState,
  Task, TaskCompletion, TaskFailure, XpTransaction,
} from "../src/core/types";
import { BRANCH_CODES } from "../src/core/branches";

function memStorage(): GameStorage & { data: {
  tasks: Task[]; completions: TaskCompletion[]; failures: TaskFailure[];
  xp: XpTransaction[]; merits: MeritTransaction[]; character: CharacterState | null;
  streak: StreakState; rewards: Reward[];
} } {
  const data = {
    tasks: [] as Task[], completions: [] as TaskCompletion[],
    failures: [] as TaskFailure[], xp: [] as XpTransaction[],
    merits: [] as MeritTransaction[], character: null as CharacterState | null,
    streak: { current: 0, best: 0, graceUsedThisWeek: false, lastCountedDate: "" } as StreakState,
    rewards: [] as Reward[],
  };
  return {
    data,
    loadTasks: () => data.tasks,
    saveTask(t) { const i = data.tasks.findIndex((x) => x.id === t.id); i >= 0 ? (data.tasks[i] = t) : data.tasks.push(t); },
    loadCompletions: () => data.completions,
    saveCompletion(c) { data.completions.push(c); },
    loadFailures: () => data.failures,
    saveFailure(f) { data.failures.push(f); },
    loadXp: () => data.xp,
    saveXp(t) { data.xp.push(t); },
    loadMerits: () => data.merits,
    saveMerit(t) { data.merits.push(t); },
    loadCharacter: () => data.character,
    saveCharacter(c) { data.character = c; },
    loadStreak: () => data.streak,
    saveStreak(s) { data.streak = s; },
    loadRewards: () => data.rewards,
    saveReward(r) { data.rewards.push(r); },
    branchTotals() {
      const t = Object.fromEntries(BRANCH_CODES.map((c) => [c, 0])) as Record<BranchCode, number>;
      for (const tx of data.xp) if (!tx.voidOf) t[tx.branch] += tx.amount;
      return t;
    },
  };
}

const habit: Task = {
  id: "t1", title: "Тест", branch: "WILL", baseXp: 30, difficulty: 2,
  kind: "habit", photoRequired: true, archived: false, createdAt: "2026-09-23T00:00:00Z",
};
const once: Task = {
  id: "t2", title: "Разовый", branch: "MIND", baseXp: 50, difficulty: 3,
  kind: "once", dueDate: "2026-09-25", photoRequired: false, archived: false,
  createdAt: "2026-09-23T00:00:00Z",
};

describe("gameService", () => {
  let store: ReturnType<typeof memStorage>;
  let svc: GameService;
  beforeEach(() => { store = memStorage(); svc = new GameService(store); });

  it("привычка видна каждый день, разовая — только в свой день", () => {
    store.saveTask(habit); store.saveTask(once);
    expect(svc.activeTasksFor("2026-09-23").map((t) => t.id)).toEqual(["t1"]);
    expect(svc.activeTasksFor("2026-09-25").map((t) => t.id)).toEqual(["t1", "t2"]);
  });

  it("один раз в день: повторный completeTask возвращает null", () => {
    store.saveTask(habit);
    const first = svc.completeTask(habit, { date: "2026-09-23", photo: "data:x" });
    expect(first?.photo).toBe("data:x");
    expect(svc.completeTask(habit, { date: "2026-09-23" })).toBeNull();
    expect(store.data.completions).toHaveLength(1);
  });

  it("сброс в 00:00: на следующую дату задача снова доступна", () => {
    store.saveTask(habit);
    svc.completeTask(habit, { date: "2026-09-23" });
    expect(svc.isCompletedOn("t1", "2026-09-23")).toBe(true);
    expect(svc.isCompletedOn("t1", "2026-09-24")).toBe(false);
    expect(svc.completeTask(habit, { date: "2026-09-24" })).not.toBeNull();
  });

  it("completion пишет XP и Merits транзакции", () => {
    store.saveTask(habit);
    svc.completeTask(habit, { date: "2026-09-23" });
    expect(store.data.xp).toHaveLength(1);
    expect(store.data.xp[0].branch).toBe("WILL");
    expect(store.data.merits.reduce((s, m) => s + m.amount, 0)).toBeGreaterThan(0);
  });
});
